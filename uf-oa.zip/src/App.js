import React from "react";
import Tetris from './Tetris';

const App = () => {
  return (
    <div style={{ height: "100vh" }}>
      <Tetris />
    </div>
  );
}

export default App;
