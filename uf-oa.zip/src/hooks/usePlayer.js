import { useState, useCallback } from 'react';

import { WORDS, randomWord } from '../words';

export const usePlayer = () => {
  const [player, setPlayer] = useState({
    pos: { x: 0, y: 0 },
    word: WORDS[0].word,
    collided: false,
  });

  //update player position
  const updatePlayerPos = ({ x, y, collided }) => {
    setPlayer(prev => ({
      ...prev,
      pos: { x: (prev.pos.x += x), y: (prev.pos.y += y) },
      collided,
    }));
  };

  //reset player position from top
  const resetPlayer = useCallback(() => {
    setPlayer({
      pos: { x: 30 / 2 - 3, y: 0 },
      word: randomWord().word,
      collided: false,
    });
  }, []);

  return [player, updatePlayerPos, resetPlayer];
};