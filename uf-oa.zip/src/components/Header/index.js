import React, { useEffect, useState } from "react";
import { HeaderWrapper } from "./style";
import UFLogo from "../../assets/images/uf_logo.svg";
// import { BsFlag } from "react-icons/bs";
import { PiFlagCheckeredFill } from "react-icons/pi";
import { GiGolfFlag } from "react-icons/gi";
import { PhoneView } from "../PhoneView";
import { randomWord } from "../../words";
import { usePlayer } from "../../hooks/usePlayer";

export const Header = ({score}) => {
  const [isMobile, setIsMobile] = useState(false);
  const [player] = usePlayer();

  useEffect(() => {
    if (window.innerWidth <= 768) setIsMobile(true);
    else setIsMobile(false);
  }, [window.innerWidth]);
  return (
    <>
      {!isMobile ? (
        <HeaderWrapper>
          {/* logo */}
          <div>
            <img src={UFLogo} alt="company-logo" />
          </div>

          {/* Next word  to drop*/}
          <div className="middle_content">
            Current word : <span>{player.word[0].join('')}</span>
          </div>

          {/* Score */}
          <div className="right_content">
            <GiGolfFlag />
            <div>
              Score <span>{score}</span>
            </div>
          </div>
        </HeaderWrapper>
      ) : (
        <PhoneView sccore={score} word={randomWord}/>
      )}
    </>
  );
};
